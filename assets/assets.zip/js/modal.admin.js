
// JQUERY
// let open_modal = $(".modal-open");

// JAVASCRIPT
// var openmodal = document.querySelectorAll('.modal-open')

// JAVASCRIPT
// for (let i = 0; i < openmodal.length; i++)
// {
//     // JAVASCRIPT
//     // openmodal[i].addEventListener('click', function(event){
//     //     event.preventDefault();
//     //     toggleModal();
//     // });
// }

// for (let i = 0; i < open_modal.length; i++) 
// {
//     // JQUERY
//     open_modal[i].click(function(e) {
//          e.preventDefault();
//         toggleModal();
//     })
// }

// const overlay = document.querySelector('.modal-overlay');
// overlay.addEventListener('click', toggleModal);

// var closemodal = document.querySelectorAll('.modal-close');

// for (var i = 0; i < closemodal.length; i++)
// {
//     closemodal[i].addEventListener('click', toggleModal);
// }

// document.onkeydown = function(evt)
// {
//     evt = evt || window.event;
//
//     var isEscape = false;
//
//     if ("key" in evt)
//     {
//         isEscape = (evt.key === "Escape" || evt.key === "Esc");
//     }
//     else
//     {
//         isEscape = (evt.keyCode === 27);
//     }
//     if (isEscape && document.body.classList.contains('modal-active'));
//     {
//         toggleModal();
//     }
// };
